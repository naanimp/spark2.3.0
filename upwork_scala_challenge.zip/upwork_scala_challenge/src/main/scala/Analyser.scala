import Analyser.formatStatement
import cesil.Lang
import cesil.Lang.{Label, _}

import scala.collection.mutable.ListBuffer

object Analyser {

  /**
    * Selects only the labelled statements in a program. For example
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * would yield
    * {{{
    *   L1     OUT
    *   L2     PRINT("Done")
    * }}}
    *
    * @param statements a program.
    * @return the sublist of labelled statements.
    */
  def filterLabelled(statements: Statements): List[Labelled] =
    (statements filter (_.isLabelled)).asInstanceOf[List[Labelled]]

  /**
    * Selects only the unlabelled statements in a program. For example
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * would yield
    * {{{
    *          IN
    *          JINEG(L2)
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *          HALT
    * }}}
    *
    * @param statements a program.
    * @return the sublist of labelled statements.
    */
  def filterUnlabelled(statements: Statements): List[Unlabelled] =
    (statements filter (_.isUnlabelled)).asInstanceOf[List[Unlabelled]]

  /**
    * Returns a list of the labels used in a program. Note that
    * each label in a program should only appear once (two statements should
    * not have the same label). However, any duplicates that may (wrongly) be
    * present in the program will still appear in the result. In the following
    * example the label `START` occurs in the result despite being redundant
    * in the program istelf.
    * {{{
    *   START  IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * returns `List(L1, L2, START)`.
    *
    * @param statements a program.
    * @return the labels in sorted order.
    */
  def getLabels(statements: Statements): List[Label] =
    (filterLabelled(statements) map (_.label)).sorted


  //Below two functions can moved out to different Object or we can make use of these methods from Pretty object by converting private method into public method.
  private def formatUnlabelled(unlabelled: Unlabelled): (String, String) = unlabelled match {
    case LOAD(variable: Var) => ("LOAD", variable.varid.toString)
    case LOAD(value: Val) => ("LOAD", value.literal.toString)
    case STORE(variable: Var) => ("STORE", variable.varid.toString)
    case JUMP(label) => ("JUMP", label.toString)
    case JINEG(label) => ("JINEG", label.toString)
    case JIPOS(label) => ("JIPOS", label.toString)
    case JIZERO(label) => ("JIZERO", label.toString)
    case PRINT(string) => ("PRINT", "\"" + string + "\"")
    case LINE => ("LINE", "")
    case IN => ("IN", "")
    case OUT => ("OUT", "")
    case ADD(variable: Var) => ("ADD", variable.varid.toString)
    case ADD(value: Val) => ("ADD", value.literal.toString)
    case SUBTRACT(variable: Var) => ("SUBTRACT", variable.varid.toString)
    case SUBTRACT(value: Val) => ("SUBTRACT", value.literal.toString)
    case MULTIPLY(variable: Var) => ("MULTIPLY", variable.varid.toString)
    case MULTIPLY(value: Val) => ("MULTIPLY", value.literal.toString)
    case DIVIDE(variable: Var) => ("DIVIDE", variable.varid.toString)
    case DIVIDE(value: Val) => ("DIVIDE", value.literal.toString)
    case MODULO(variable: Var) => ("MODULO", variable.varid.toString)
    case MODULO(value: Val) => ("MODULO", value.literal.toString)
    case PUSH => ("PUSH", "")
    case POP => ("POP", "")
    case SWAP => ("SWAP", "")
    case NOP => ("NOP", "")
    case HALT => ("HALT", "")
  }

  def formatStatement(statement: Statement): (String, String) = statement match {
    case Labelled(label, unlabelled) => formatUnlabelled(unlabelled)
    case unlabelled: Unlabelled => formatUnlabelled(unlabelled)
  }

  /**
    * Returns a list of program statements stripped of labels. The resulting
    * list is not (intentionally) useful as a program because label references
    * in jump statements will no longer have labels to match. However, the
    * resulting list can be used as part of some further program analysis.
    * For example, the program
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * becomes
    * {{{
    *          IN
    *          JINEG(L2)
    *          OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *          PRINT("Done")
    *          HALT
    * }}}
    *
    * @param statements a program.
    * @return the program (in original order) with labels removed.
    */
  def stripLabels(statements: Statements): List[Unlabelled] =
    statements map {
      case Labelled(_, unlabelled) => unlabelled
      case unlabelled: Unlabelled => unlabelled
    }

  /**
    * Returns an alphabetical list of the statement types used by the program. For
    * example
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * returns
    * `List(HALT, IN, JINEG, JIZERO, JUMP, LINE, OUT, PRINT, SUBTRACT)`.
    *
    * @param statements a program.
    * @return the list of statement type names in alphabetical order without duplicates.
    */
  def listStatementTypesUsed(statements: Statements): List[String] =
    statements.map { statement: Statement => formatStatement(statement)._1 }.distinct.sorted

  /**
    * Returns a list of label references used in a program. The list is
    * sorted and duplicates removed. In the following example the redundant
    * label `START` is not referenced and is thus not included in the result.
    * Both `L1` and `L2` are referenced. Therefore the program
    * {{{
    *   START  IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * yields `List(L1, L2)`.  Note that if a program (wrongly) contains
    * references to non-existant labels then these too will be included in
    * the result.
    *
    * @param statements a program.
    * @return the list of unique label references in sorted order.
    */
  def getLabelRefs(statements: Statements): List[Label] =
    statements.map { statement: Statement => formatStatement(statement)._2 }
      .filter(x => !x.isEmpty)
      .distinct
      .sorted

  /**
    * Returns an ordered list of all (redundant) labels in a program. A redundant label
    * is one that has no reference. The resulting list may be empty if all labels in a
    * program are referenced. Therefore the program
    * {{{
    *   START  IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * returns `List(START)`.
    *
    * @param statements a program.
    * @return the ordered list of redundant labels.
    */
  def redundantLabels(statements: Statements): List[Label] =
    (statements filter (_.isLabelled))
      .map(x => x.asInstanceOf[Labelled].label)
      .distinct
      .diff(statements.map { statement: Statement => formatStatement(statement)._2 }.filter(x => !x.isEmpty).distinct)
      .sorted

  /**
    * Returns an ordered list of all missing labels in a program. A missing label
    * is one that is expected by some label reference. The resulting list may be empty
    * if no labels in a program are missing. Therefore the program
    * {{{
    *   START  IN
    *          JINEG(L2)
    *          OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * returns `List(L1)`.
    *
    * @param statements a program.
    * @return the ordered list of redundant labels.
    */
  def missingLabels(statements: Statements): List[Label] = {
    statements.map {
      statement: Statement => formatStatement(statement)._2
    }.filter(x => !(x.isEmpty))
      .distinct
      .diff(
        (statements filter (_.isLabelled))
          .map(x => x.asInstanceOf[Labelled].label)
          .distinct
      ).sorted
  }

  /**
    * Attaches line numbers (indexes) to a program starting with index 0. This method
    * is used by the [[VirtualMachine]] when a program is loaded so that its program
    * counter can step through the statements in turn.
    *
    * @param statements a program.
    * @return a list of (index, statement) pairs.
    */
  def indexProgram(statements: Statements): List[(Int, Statement)] =
    (statements.indices zip statements).toList

  /**
    * Returns a mapping of labels and their respective line numbers.
    * For example, if the following program is input
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     PRINT("Done")
    *          HALT
    * }}}
    * then the mapping generated is: `( L1 -> 2, L2 -> 7 )`. This method is called
    * by the [[VirtualMachine]] when loading and analysing a program.
    *
    * @param statements a program.
    * @return a `Map` associating each label with the index of the line
    *         on which it is defined.
    */
  def makeLabelIndexMap(statements: Statements): Map[Label, Int] =
    (indexProgram(statements) filter (_._2.isLabelled) map {
      case (index, Labelled(label, _)) => label -> index
    }).toMap

  /**
    * Removes all PUSH/POP pairs. A PUSH followed immediately by a POP leaves the
    * machine state exactly as it was before the PUSH. Therefore such pairs of
    * statements can be removed safely. For example, the following program fragment
    * {{{
    *   #30    NOP
    *          LOAD      x
    *          PUSH
    *          POP
    *          STORE     y
    *          LOAD      n
    *          SUBTRACT  y
    * }}}
    * can be reduced to
    * {{{
    *   #30    NOP
    *          LOAD      x
    *          STORE     y
    *          LOAD      n
    *          SUBTRACT  y
    * }}}
    * However, care must be taken if either of the PUSH/POP statements is labelled.
    * If the POP is labelled then the optimisation is not possible (because the POP
    * may be executed after ''any'' statement that references its label). If the PUSH
    * is labelled then the label needs to be preserved following the optimisation.
    * In this case the PUSH/POP pair can be replaced by a labelled NOP. ('''N.B.'''
    * NOPs may be removed subsequently using another optimisation: [[stripNOPs]]).
    * {{{
    *   #30    NOP
    *          LOAD      x
    *   #42    PUSH
    *          POP
    *          STORE     y
    *          LOAD      n
    *          SUBTRACT  y
    * }}}
    * can be reduced to
    * {{{
    *   #30    NOP
    *          LOAD      x
    *   #42    NOP
    *          STORE     y
    *          LOAD      n
    *          SUBTRACT  y
    * }}}
    *
    * @param statements a program.
    * @return the program with unlabelled PUSH/POP pairs removed and any
    *         labelled PUSH/unlabelled POP pairs replaced by a labelled NOP.
    */
  def stripPushPopPairs(statements: Statements): Statements = {
    if (statements.size > 0) {
      val stripedOutPushPopPairs = stripAllPushPopPairs(statements)
      if (stripedOutPushPopPairs.length > 0) {
        var lastItem = stripedOutPushPopPairs.head;
        val resStatements = stripedOutPushPopPairs.tail.foldLeft(ListBuffer.empty[Statement])((list, stmt) => {
          val head = stmt.head
          if ((lastItem.isInstanceOf[Labelled] && head.isInstanceOf[Unlabelled])
            && (formatStatement(lastItem)._1 == "PUSH" && formatStatement(head)._1 == "POP")
          ) {
            val lbl = if (lastItem.isInstanceOf[Labelled]) lastItem.asInstanceOf[Labelled].label else head.asInstanceOf[Labelled].label
            list.append((lbl :: NOP))
            lastItem = null
          } else if (lastItem == null) {
            lastItem = head
          } else {
            list.append(lastItem)
            lastItem = head
          }
          list
        })
        if (lastItem != null) resStatements.append(lastItem)
        resStatements.toList.asInstanceOf[Statements]
      } else {
        stripedOutPushPopPairs.toList
      }
    } else {
      statements
    }
  }

  /**
    * Removes all unlabelled NOP statements. Such statements can be filtered out without
    * changing the meaning of the program.
    *
    * @param statements a program.
    * @return the program with all unlabelled NOPs removed.
    */
  def stripUnlabelledNOPs(statements: Statements): Statements =
    statements filter (x => {
      if (x.isInstanceOf[Unlabelled] && formatStatement(x)._1 == "NOP") false else true
    })


  /**
    * Removes all labelled NOP statements. A labelled NOP can have its label transferred
    * to the following statement. Then all statements that refer to this label must have
    * their references updated. For example
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     NOP
    *          LOAD(Val(2))
    * }}}
    * In this case the label L2 can be transferred to the subsequent statement:
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     LOAD(Val(2))
    * }}}
    * However, if the subsequent statement is labelled then a relabelling of
    * references is necessary. For example
    * {{{
    *          IN
    *          JINEG(L2)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L2     NOP
    *   L3     LOAD(Val(2))
    * }}}
    * In this case the label L2 is redundant and references to L2 need to be changed
    * to refer to L3.
    * {{{
    *          IN
    *          JINEG(L3)
    *   L1     OUT
    *          LINE
    *          JIZERO(L3)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L3     LOAD(Val(2))
    * }}}
    * In general, a sequence of labelled NOPs can be handled similarly:
    * {{{
    *          IN
    *          JINEG(L4)
    *   L1     OUT
    *          LINE
    *          JIZERO(L2)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L4     NOP
    *   L2     NOP
    *   L3     LOAD(Val(2))
    * }}}
    * In this example any references to L2 or L4 must all be changed to refer
    * to label L3
    * {{{
    *          IN
    *          JINEG(L3)
    *   L1     OUT
    *          LINE
    *          JIZERO(L3)
    *          SUBTRACT(Val(1))
    *          JUMP(L1)
    *   L3     LOAD(Val(2))
    * }}}
    * However, if the very last statement is a labelled NOP then this cannot be removed.
    * (There is no subsequent statement to which to attach the label). In such programs
    * the final statement remains a labelled NOP.
    *
    * @param statements a program.
    * @return a program with the labelled NOPs removed and associated references relabelled.
    */
  def stripLabelledNOPs(statements: Statements): Statements = {
    statements.size match {
      case 0 => statements
      case _ => {
        var lastItem = statements.head;
        val unlabelledListWithOutPushPops = statements.tail.foldLeft(ListBuffer.empty[Statement])((list, stmt) => {
          val head = stmt.head
          if (lastItem != null && lastItem.isInstanceOf[Labelled] && formatStatement(lastItem)._1 == "NOP") {
            lastItem = if (head.isInstanceOf[Labelled]) head else Labelled(lastItem.asInstanceOf[Labelled].label, head.asInstanceOf[Unlabelled])
          } else {
            list.append(lastItem)
            lastItem = head;
          }
          list
        })
        if (lastItem != null) unlabelledListWithOutPushPops.append(lastItem)
        unlabelledListWithOutPushPops.toList
      }
    }
  }


  /**
    * Removes all NOP statements (performing any relabelling that may be needed). This is
    * achieved in two passes: firstly, remove the unlabelled NOPs using [[stripUnlabelledNOPs]];
    * and then remove the labelled NOPs using [[stripLabelledNOPs]]. This funtion is
    * constructed using functional composition.
    */
  val stripNOPs: Statements => Statements = stripLabelledNOPs _ compose stripUnlabelledNOPs _

  def stripAllPushPopPairs(statements: Statements): Statements = {
    statements.size match {
      case 0 => statements
      case _ => {
        var lastItem = statements.head;
        val stripedOutPushPopPairs = statements.tail.foldLeft(ListBuffer.empty[Statement])((list, stmt) => {
          val head = stmt.head
          lastItem = lastItem match {
            case x if(x != null && x.isInstanceOf[Unlabelled] && head.isInstanceOf[Unlabelled]
              && formatStatement(lastItem)._1 == "PUSH" && formatStatement(head)._1 == "POP") => null
            case x if(x == null) => head
            case _ => list.append(lastItem); head
          }
          list
        })
        if (lastItem != null) stripedOutPushPopPairs.append(lastItem)
        stripedOutPushPopPairs.toList
      }
    }

  }
}
